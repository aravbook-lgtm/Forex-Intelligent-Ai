# Forex Intelligence AI — starter Android project

This is an early prototype. It contains an app screen, Android overlay permission flow,
a small floating bubble, and a GitHub Actions workflow that builds a **debug APK**.

## Build from a phone using GitHub
1. Sign in to GitHub and create a new **public or private** repository.
2. Upload the contents of this ZIP to the repository (keep the `.github/workflows` folder).
3. Open the repository's **Actions** tab.
4. Select **Build Forex Intelligence AI APK**, then **Run workflow** (or push to `main`).
5. When the run succeeds, open it and download the `ForexIntelligenceAI-debug-apk` artifact.
6. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.
7. Android may ask you to allow installation from that browser/file manager. Only install the APK you built from your own repository.

## Current limitations
This is NOT the complete trading system. It has no voice recognition, screen capture,
live forex feed, 1,000-agent voting, memory/learning backend, or trading execution.
The floating bubble is a UI prototype. Debug APKs are for testing, not Play Store release.
