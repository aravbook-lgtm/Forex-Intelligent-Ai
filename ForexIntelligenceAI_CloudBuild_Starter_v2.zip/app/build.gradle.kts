plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.forexintelligenceai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.forexintelligenceai"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}
